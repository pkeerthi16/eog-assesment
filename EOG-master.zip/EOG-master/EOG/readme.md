## Setup 

Install Dependencies:

```
yarn install
```

OR

```
npm install
```

## Start dev server

```
yarn start
```

OR

```
npm run start
```